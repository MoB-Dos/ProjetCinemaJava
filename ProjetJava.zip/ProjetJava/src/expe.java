import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class expe extends JFrame {
	
	//CTRL + SHIFT + O pour g�n�rer les imports
	BDDtest frite = new BDDtest();
	Object[][] data = null;
	
	  public expe(){
	    this.setLocationRelativeTo(null);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setTitle("JTable");
	    this.setSize(700, 420);
	    
	    data = frite.select();

	    //Les donn�es du tableau
	

	    //Les titres des colonnes
	    String  title[] = {"numero", "nombre", "Etud","Dix","Navigo","PleinTarif","film","date"};
	    JTable tableau = new JTable(data, title);
	    //Nous ajoutons notre tableau � notre contentPane dans un scroll
	    //Sinon les titres des colonnes ne s'afficheront pas !
	    this.getContentPane().add(new JScrollPane(tableau));
	  }   
	  
public static void main(String[] args){
	    expe fen = new expe();
	    fen.setVisible(true);
	  }
}