                                                             

public class test {

	public static void main(String[] args) {
		
		fenetre fen = new fenetre();
		
	}

}
                      