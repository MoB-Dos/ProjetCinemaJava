
import java.awt.*;  
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.applet.*;


public class fenetre extends JFrame {
	
	JPanel panel = new JPanel();
    JPanel bilanPanel = new JPanel();
    
  
	private JFormattedTextField Pfield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private JFormattedTextField Afield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private JFormattedTextField Efield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private JFormattedTextField Nfield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private JFormattedTextField PTfield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private String choix[] = {" Annihilation", "Drive", "Les Miserables"};    
	private JComboBox film = new JComboBox(choix);
	
	DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
	Date date = new Date();
	String date1 = format.format(date);
	
     
	BDD steak = new BDD();
	
	int numero = 1;
	
  public fenetre(){
	  				
	  			
	  			int test;
	  			
			    this.setTitle("Junior");
			    this.setSize(600, 350);
			    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			   
				
			    this.panel.setLayout(null);
			    this.bilanPanel.setLayout(null);
			 
		
			   
			    
				JLabel lb_text = new JLabel();
			        lb_text.setFont(new Font("Verdana", 1, 12));
			        lb_text.setForeground(new Color(0, 0, 0));
			        lb_text.setText("Choissisez le prix, les places et le film !");
			        lb_text.setBounds(140, 10,500, 20);
			        panel.add(lb_text);
			        
			        
			        
			        
			Pfield.setBounds(205, 70, 40, 20);
			
			 			panel.add(Pfield);
			 			
			Efield.setBounds(127, 100, 40, 20);
			 			panel.add(Efield);
			 			
			Afield.setBounds(126, 120, 40, 20);
			 			panel.add(Afield);

			 			
			Nfield.setBounds(110, 140, 40, 20);
			 			panel.add(Nfield);
			 			
			PTfield.setBounds(130, 160, 40, 20);
			 			panel.add(PTfield);
			 			
			 JLabel personneTxt = new JLabel();
				    personneTxt.setFont(new Font("Verdana", 1, 12));
				    personneTxt.setForeground(new Color(0, 0, 0));
				    personneTxt.setText("Nombre de Personne :");
				    personneTxt.setBounds(50, 70,500, 20);
			        panel.add(personneTxt);
			        
			        
			        
			 JLabel prixETxt = new JLabel();
				    prixETxt.setFont(new Font("Verdana", 1, 12));
				    prixETxt.setForeground(new Color(0, 0, 0));
				    prixETxt.setText("Etudiants :");
				    prixETxt.setBounds(50, 100,500, 20);
			        panel.add(prixETxt);
			            
			        
			   	 JLabel prixATxt = new JLabel();
				    prixATxt.setFont(new Font("Verdana", 1, 12));
				    prixATxt.setForeground(new Color(0, 0, 0));
				    prixATxt.setText("(-10) ans :");
				    prixATxt.setBounds(50, 120,500, 20);
			        panel.add(prixATxt);
			            
			        
			        
			   	 JLabel prixNTxt = new JLabel();
				    prixNTxt.setFont(new Font("Verdana", 1, 12));
				    prixNTxt.setForeground(new Color(0, 0, 0));
				    prixNTxt.setText("Navigo :");
				    prixNTxt.setBounds(50, 140,500, 20);
			        panel.add(prixNTxt);
			       
			        
			   	 JLabel prixPTxt = new JLabel();
				    prixPTxt.setFont(new Font("Verdana", 1, 12));
				    prixPTxt.setForeground(new Color(0, 0, 0));
				    prixPTxt.setText("Plein tarif :");
				    prixPTxt.setBounds(50, 160,500, 20);
			        panel.add(prixPTxt);
			            
			        
			        
				 JLabel filmTxt = new JLabel();
				 		filmTxt.setFont(new Font("Verdana", 1, 12));
				 		filmTxt.setForeground(new Color(0, 0, 0));
				 		filmTxt.setText("choix du film :");
				 		filmTxt.setBounds(50, 190,500, 20);
				        panel.add(filmTxt);
				            
						
					  film.setBounds(155, 190,100, 20);
					  panel.add(film);
					  
					  this.setContentPane(panel); 
					    this.setVisible(true);   
					    
				JButton submit = new JButton("Valider !");
				JButton bilan = new JButton("Voir le Bilan");
				JButton retour = new JButton("Retour");
				
				submit.setBounds(210, 240,100, 20);
				submit.addActionListener(new BoutonListener());
				panel.add(submit);
				
				bilan.setBounds(20, 270,120, 20);
				bilan.addActionListener(new BilanListener());
				panel.add(bilan);
				
				retour.setBounds(20, 20,90, 20);
				retour.addActionListener(new RetourListener());
				bilanPanel.add(retour);
				
				
	
  
  }

  public void changerMenu2(){
	  this.setContentPane(this.bilanPanel);
      this.revalidate();;}
  
  public void changerMenu1(){
	  this.setContentPane(this.panel);
      this.revalidate();;}
  
				  class BoutonListener implements ActionListener{
					 
					    public void actionPerformed(ActionEvent e) {
					    	
					    	int res = Integer.valueOf(Efield.getText()) + Integer.valueOf(Afield.getText()) + Integer.valueOf(Nfield.getText()) + Integer.valueOf(PTfield.getText());
					    	
					    	if(res == Integer.valueOf(Pfield.getText())) 
					    	{
					    	System.out.println(res);
					    	System.out.println("TEXT :" + film.getSelectedItem());
					    	System.out.println("TEXT :" + Pfield.getText());
					    	System.out.println("TEXT :" + Efield.getText());
					    	System.out.println("TEXT :" + Afield.getText());
					    	System.out.println("TEXT :" + Nfield.getText());
					    	System.out.println("TEXT :" + PTfield.getText());
					    	
					    	
					    	
					    	String Nbm = Pfield.getText();
					    	String Etud = Efield.getText();
					    	String Dix = Afield.getText();
					    	String Navigo = Nfield.getText();
					    	String PleinTarif = PTfield.getText();
					    	String filmA = (String) film.getSelectedItem();
					    	
					    	//steak.ajout(numero,Nbm,Etud,Dix,Navigo,PleinTarif,filmA,date1);
				    	}
					    	else {System.out.println("erreur");}
					    	
					   
					    	
					    	
					    }
					    	
					  }
				  
				  class BilanListener implements ActionListener{
						 
					    public void actionPerformed(ActionEvent e) {
					    	
					    	
					    	fenetre.this.changerMenu2();
					    	
					    }
					    	
					  }
				  
				  class RetourListener implements ActionListener{
						 
					    public void actionPerformed(ActionEvent e) {
					    	
					    	
					    	fenetre.this.changerMenu1();
					    	
					    }
					    	
					  }
		  
  }		
