
import java.awt.*;  
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JScrollPane;
import javax.swing.JTable;



public class fenetre extends JFrame {
	
	//creation des panel
	JPanel panel = new JPanel();
    JPanel bilanPanel = new JPanel();
  
    //on instancie de la BDD
    BDD MaBDD = new BDD();
    
    //creation des TextField et Label
	private JFormattedTextField Pfield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private JFormattedTextField Afield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private JFormattedTextField Efield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private JFormattedTextField Nfield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	private JFormattedTextField PTfield = new JFormattedTextField(NumberFormat.getIntegerInstance());
	JLabel ResString = new JLabel();
	JLabel ResPrice = new JLabel();

	//on attribut les prix
	int EtudP = (int) 7.50;
	int DixP = (int) 5;
	int NavP = (int) 8;
	int PTP = (int) 11;
	
	
	//creation des boutons
    JButton submit = new JButton("Valider !");
    JButton bilan = new JButton("Voir le Bilan");
	JButton reset = new JButton("Reset");
				
	
	//creation des Listes deroulantes
	private String choix[] = {" Annihilation", "Drive", "Les Miserables"};    
	private JComboBox film = new JComboBox(choix);
	
	private Object[] choixDate = MaBDD.ListeDate();    
	private JComboBox ListeDate = new JComboBox(choixDate);
	
	//on recupere la Date pour l'insertion
	DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
	Date date = new Date();
	String date1 = format.format(date);
	
	
  
	
  public fenetre(){
	  		
	  
	  //on met tout les textfield a zero pour gagner du temps
		Pfield.setText("0");
		Afield.setText("0");
		Efield.setText("0");
		Nfield.setText("0");
		PTfield.setText("0");
	  
	  
	  
	  			//on set notre fenetre
			    this.setTitle("Reservation Place ");
			    this.setSize(600, 350);
			    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			   
				//on set nos panel
			    this.panel.setLayout(null);
			    this.bilanPanel.setLayout(null);
			 		        
			        
			//on definis la position et on ajoute les JTEXTFIELD
			Pfield.setBounds(205, 70, 40, 20);
			 			panel.add(Pfield);
			 			
			Efield.setBounds(127, 100, 40, 20);
			 			panel.add(Efield);
			 			
			Afield.setBounds(126, 120, 40, 20);
			 			panel.add(Afield);

			 			
			Nfield.setBounds(110, 140, 40, 20);
			 			panel.add(Nfield);
			 			
			PTfield.setBounds(130, 160, 40, 20);
			 			panel.add(PTfield);
			
			//on definis la position et on ajoute la Liste Deroulante
			film.setBounds(155, 190,100, 20);
						  panel.add(film);
			
			ListeDate.setBounds(430, 90,100, 20);
						  panel.add(ListeDate);
			 			
			 //on definie et on ajoute les JLABEL	
			 JLabel lb_text = new JLabel();
				    lb_text.setFont(new Font("Verdana", 1, 12));
				    lb_text.setForeground(new Color(0, 0, 0));
				    lb_text.setText("Choissisez le prix, les places et le film !");
				    lb_text.setBounds(140, 10,500, 20);
				    panel.add(lb_text);
				        
			 JLabel personneTxt = new JLabel();
				    personneTxt.setFont(new Font("Verdana", 1, 12));
				    personneTxt.setForeground(new Color(0, 0, 0));
				    personneTxt.setText("Nombre de Personne :");
				    personneTxt.setBounds(50, 70,500, 20);
			        panel.add(personneTxt);
			        
			 JLabel prixETxt = new JLabel();
				    prixETxt.setFont(new Font("Verdana", 1, 12));
				    prixETxt.setForeground(new Color(0, 0, 0));
				    prixETxt.setText("Etudiants :");
				    prixETxt.setBounds(50, 100,500, 20);
			        panel.add(prixETxt);
			            
			 JLabel prixATxt = new JLabel();
				    prixATxt.setFont(new Font("Verdana", 1, 12));
				    prixATxt.setForeground(new Color(0, 0, 0));
				    prixATxt.setText("(-10) ans :");
				    prixATxt.setBounds(50, 120,500, 20);
			        panel.add(prixATxt);
			             
			 JLabel prixNTxt = new JLabel();
				    prixNTxt.setFont(new Font("Verdana", 1, 12));
				    prixNTxt.setForeground(new Color(0, 0, 0));
				    prixNTxt.setText("Navigo :");
				    prixNTxt.setBounds(50, 140,500, 20);
			        panel.add(prixNTxt);
			       
			 JLabel prixPTxt = new JLabel();
				    prixPTxt.setFont(new Font("Verdana", 1, 12));
				    prixPTxt.setForeground(new Color(0, 0, 0));
				    prixPTxt.setText("Plein tarif :");
				    prixPTxt.setBounds(50, 160,500, 20);
			        panel.add(prixPTxt);
			            
		     JLabel filmTxt = new JLabel();
				    filmTxt.setFont(new Font("Verdana", 1, 12));
				 	filmTxt.setForeground(new Color(0, 0, 0));
				 	filmTxt.setText("choix du film :");
				 	filmTxt.setBounds(50, 190,500, 20);
				    panel.add(filmTxt);
			
			
			ResString.setFont(new Font("Verdana", 1, 12));
			ResString.setForeground(new Color(0, 0, 0));
			ResString.setText(" ");
			ResString.setBounds(190, 270,500, 20);
			panel.add(ResString);
			panel.add(ResString);
				   
		
			ResPrice.setFont(new Font("Verdana", 1, 12));
			ResPrice.setForeground(new Color(0, 0, 0));
			ResPrice.setText(" ");
			ResPrice.setBounds(330, 240,500, 20);
			panel.add(ResPrice);
				   
						
			//on definis les boutons
		     submit.setBounds(210, 240,100, 20);
		     submit.addActionListener(new BoutonListener());
			 panel.add(submit);
				
			 bilan.setBounds(420, 130,120, 20);
			 bilan.addActionListener(new BilanListener());
			 panel.add(bilan);
				
			 reset.setBounds(460, 260,90, 20);
		     reset.addActionListener(new ResetListener());
			 panel.add(reset);
			
			 //on affiche le Panel
			 this.setContentPane(panel); 
			 
  }
  



 

  
 //ActionListener du bouton "Valider"
 class BoutonListener implements ActionListener{
					 
public void actionPerformed(ActionEvent e) {
					    	
	//on verifie bien que le nombre de place donnee est egal au nombre de personne
	int res = Integer.valueOf(Efield.getText()) + Integer.valueOf(Afield.getText()) + Integer.valueOf(Nfield.getText()) + Integer.valueOf(PTfield.getText());
					    	
	if(res == Integer.valueOf(Pfield.getText())) 
	{
		
	//on calcule le prix total a payer
	int price = (EtudP*Integer.valueOf(Efield.getText())) + (DixP*Integer.valueOf(Afield.getText())) + (NavP*Integer.valueOf(Nfield.getText())) + (PTP*Integer.valueOf(PTfield.getText()));
	
	//on prepare les variables pour l'insertion
	System.out.println(res);
	System.out.println("TEXT :" + film.getSelectedItem());
	System.out.println("TEXT :" + Pfield.getText());
	System.out.println("TEXT :" + Efield.getText());
	System.out.println("TEXT :" + Afield.getText());
	System.out.println("TEXT :" + Nfield.getText());
	System.out.println("TEXT :" + PTfield.getText());
					    	
	String Nbm = Pfield.getText();
	String Etud = Efield.getText();
	String Dix = Afield.getText();
	String Navigo = Nfield.getText();
	String PleinTarif = PTfield.getText();
	String filmA = (String) film.getSelectedItem();
					  
	//on insert avec nos variables 
	MaBDD.ajout(Nbm,Etud,Dix,Navigo,PleinTarif,filmA,date1);
	
	ResString.setText("Transaction reussie !");
	String priceString = Integer.toString (price);
	ResPrice.setText(priceString);
	
	}
	else {ResString.setText("le nombre de personne n'est pas atteint");;}
					    		
	}
 }

 //methode pour afficher Le Bilan
class BilanListener implements ActionListener{
						 
public void actionPerformed(ActionEvent e) {
		
	String date2 = (String) ListeDate.getSelectedItem();
	
	  expe ChangeFen2 = new expe(date2);
	  ChangeFen2.setVisible(true);
 }
					    	
}
	
//methode pour Reset les Textfield
class ResetListener implements ActionListener{
						 
public void actionPerformed(ActionEvent e) {
	
	Pfield.setText("0");
	Afield.setText("0");
	Efield.setText("0");
	Nfield.setText("0");
	PTfield.setText("0");    	

					    	
  }

}
		  
 }





