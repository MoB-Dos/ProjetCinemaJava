

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Statement;


public class BDD {
	
	
	public void ajout(int numero,String Nbm,String Etud,String Navigo,String Dix, String Pleintarif, String filmA, String date1) {
		
			String url="jdbc:mysql://localhost/projet_cinema?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
			String user="root";
			String password ="";
			
			try {
				Connection cnx = DriverManager.getConnection(url,user,password);
				Statement stmt = cnx.createStatement();
		        ResultSet rs;    
		        stmt.executeUpdate("INSERT INTO stockagebilan (numero, nombre,Etud,Navigo,Dix,Pleintarif, film, date)" + "VALUES (" + numero + " ,"+ Nbm + " ,'"+ Etud + "','"+ Dix + "','"+ Navigo + "','"+ Pleintarif + "', '"+ filmA +"','"+ date1 +"')");
		        
		        //System.out.println("insertion reussie !");
		            
		            cnx.close();
			}catch (SQLException e) {
				System.out.println("Une erreur est survenue lors de la connexion a la base de donn�es");
				e.printStackTrace();
				
			}
	}
	
	public void select() {
		
		 
		
		
		String url="jdbc:mysql://localhost/projet_cinema?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
		String user="root";
		String password ="";
		
		try {
			Connection cnx = DriverManager.getConnection(url,user,password);
			Statement stmt = cnx.createStatement();
	        ResultSet rs;    
	        stmt.executeUpdate("SELECT * FROM stockagebilan WHERE 1");
	        
	        
	        System.out.println("insertion reussie !" );
	            
	            cnx.close();
		}catch (SQLException e) {
			System.out.println("Une erreur est survenue lors de la connexion a la base de donn�es");
			e.printStackTrace();
			
		}
		
}


}	
	

