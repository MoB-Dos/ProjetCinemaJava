import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;







public class BDDtest {
//  Query1.java:  Query an mSQL database using JDBC. 


/**
 * A JDBC SELECT (JDBC query) example program.
 * @return 
 */
        
	  
	  
	  
	  public Object[][] select() {
		  
		  List<Object[]> objs = new LinkedList<>();
		  Object[][] tab = new Object[5][objs.size()];
	  
	  try {
            String url = "jdbc:mysql://localhost/projet_cinema?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String user="root";
    		String password ="";
    		Connection conn = DriverManager.getConnection(url,user,password);
            Statement stmt = conn.createStatement();
            ResultSet rs;
 
            rs = stmt.executeQuery("SELECT (numero,nombre,etud,Dix,NAvigo,PleinTarif,film,date) FROM stockagebilan WHERE 1");
            
           
            
            while (rs.next()){
            		int numero = rs.getInt("numero");
            		int nombre= rs.getInt("nombre");
                    int etud = rs.getInt("etud");
                    int Dix = rs.getInt("Dix");
                    int Navigo= rs.getInt("Navigo");
                    int PleinTarif= rs.getInt("PleinTarif");
                    String film= rs.getString("film");
                    String date= rs.getString("date");
                    
                    
                    Object[] obj = new Object[5];
                    obj[0] = numero;
                    obj[1] = nombre;
                    obj[2] = etud;
                    obj[3] = Dix;
                    obj[4] = Navigo;
                    obj[5] = PleinTarif;
                    obj[6] = film;
                    obj[7] = date;
                    objs.add(obj);
            }
            
            objs.toArray(tab);
            
            return tab;
            
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
	  
	  return tab;
    }
}
  